const express= require("express");
const router=express.Router();

router.route("/api/register_customer").post((req, res) => {
    const name= req.body.name;
    const email=req.body.email;
    const encryptedPassword= cryptr.encrypt(req.body.password);
    const location=req.body.location;
    const sqlInsert = 
    "INSERT INTO customer (name,email,password,location) VALUES (?,?,?,?);";
    db.query(sqlInsert,[name,email,encryptedPassword,location],(err,result)=>{

        if (error) {
            res.json({
                status:false,
                message:'there are some error with query'
            })
          }else{
              res.json({
                status:true,
                message:'user registered sucessfully'
            })
          }
    

    });
});

module.exports = router;
